# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Copyright 2018 VMware, Inc.  All rights reserved.

# AUTO GENERATED FILE -- DO NOT MODIFY!
#
# vAPI stub file for package com.vmware.vcenter.vm_template.library_items.
#---------------------------------------------------------------------------

"""
The ``com.vmware.vcenter.vm_template.library_items_client`` module provides
classes and classes for managing checked out virtual machine template items.

"""

__author__ = 'VMware, Inc.'
__docformat__ = 'restructuredtext en'

import sys

from vmware.vapi.bindings import type
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.bindings.enum import Enum
from vmware.vapi.bindings.error import VapiError
from vmware.vapi.bindings.struct import VapiStruct
from vmware.vapi.bindings.stub import (
    ApiInterfaceStub, StubFactoryBase, VapiInterface)
from vmware.vapi.bindings.common import raise_core_exception
from vmware.vapi.data.validator import (UnionValidator, HasFieldsOfValidator)
from vmware.vapi.exception import CoreException
from vmware.vapi.lib.constants import TaskType
from vmware.vapi.lib.rest import OperationRestMetadata


class CheckOuts(VapiInterface):
    """
    The ``CheckOuts`` class provides methods for managing the checkouts of a
    library item containing a virtual machine template. This class provides
    operations to check out a library item to update the virtual machine
    template, and to check in the library item when the virtual machine changes
    are complete. **Warning:** This class is part of a new feature in
    development. It may be changed at any time and may not have all supported
    functionality implemented.
    """


    def __init__(self, config):
        """
        :type  config: :class:`vmware.vapi.bindings.stub.StubConfiguration`
        :param config: Configuration to be used for creating the stub.
        """
        VapiInterface.__init__(self, config, _CheckOutsStub)

    class CheckOutSpec(VapiStruct):
        """
        The ``CheckOuts.CheckOutSpec`` class defines the information required to
        check out a library item containing a virtual machine template.
        **Warning:** This class is part of a new feature in development. It may be
        changed at any time and may not have all supported functionality
        implemented.

        .. tip::
            The arguments are used to initialize data attributes with the same
            names.
        """




        def __init__(self,
                     name=None,
                     placement=None,
                    ):
            """
            :type  name: :class:`str` or ``None``
            :param name: Name of the virtual machine to check out of the library item.
                **Warning:** This attribute is part of a new feature in
                development. It may be changed at any time and may not have all
                supported functionality implemented.
                This attribute is currently required. In the future, if this
                attribute is None, the system will choose a suitable name for the
                virtual machine.
            :type  placement: :class:`CheckOuts.PlacementSpec` or ``None``
            :param placement: Information used to place the checked out virtual machine.
                **Warning:** This attribute is part of a new feature in
                development. It may be changed at any time and may not have all
                supported functionality implemented.
                This attribute is currently required. In the future, if this
                attribute is None, the system will place the virtual machine on a
                suitable resource. 
                
                If specified, each attribute will be used for placement. If the
                attributes result in disjoint placement, the operation will fail.
                If the attributes along with the placement values of the source
                virtual machine template result in disjoint placement, the
                operation will fail. 
            """
            self.name = name
            self.placement = placement
            VapiStruct.__init__(self)

    CheckOutSpec._set_binding_type(type.StructType(
        'com.vmware.vcenter.vm_template.library_items.check_outs.check_out_spec', {
            'name': type.OptionalType(type.StringType()),
            'placement': type.OptionalType(type.ReferenceType(__name__, 'CheckOuts.PlacementSpec')),
        },
        CheckOutSpec,
        False,
        None))


    class PlacementSpec(VapiStruct):
        """
        The ``CheckOuts.PlacementSpec`` class contains information used to place a
        checked out virtual machine onto resources within the vCenter inventory.
        The specified compute resource should have access to the storage associated
        with the checked out virtual machine. **Warning:** This class is part of a
        new feature in development. It may be changed at any time and may not have
        all supported functionality implemented.

        .. tip::
            The arguments are used to initialize data attributes with the same
            names.
        """




        def __init__(self,
                     folder=None,
                     resource_pool=None,
                     host=None,
                     cluster=None,
                    ):
            """
            :type  folder: :class:`str` or ``None``
            :param folder: Virtual machine folder into which the virtual machine should be
                placed. **Warning:** This attribute is part of a new feature in
                development. It may be changed at any time and may not have all
                supported functionality implemented.
                When clients pass a value of this class as a parameter, the
                attribute must be an identifier for the resource type: ``Folder``.
                When methods return a value of this class as a return value, the
                attribute will be an identifier for the resource type: ``Folder``.
                If None, the virtual machine will be placed in the same folder as
                the source virtual machine template.
            :type  resource_pool: :class:`str` or ``None``
            :param resource_pool: Resource pool into which the virtual machine should be placed.
                **Warning:** This attribute is part of a new feature in
                development. It may be changed at any time and may not have all
                supported functionality implemented.
                When clients pass a value of this class as a parameter, the
                attribute must be an identifier for the resource type:
                ``ResourcePool``. When methods return a value of this class as a
                return value, the attribute will be an identifier for the resource
                type: ``ResourcePool``.
                If None, the system will attempt to choose a suitable resource pool
                for the virtual machine; if a resource pool cannot be chosen, the
                operation will fail.
            :type  host: :class:`str` or ``None``
            :param host: Host onto which the virtual machine should be placed. If ``host``
                and ``resourcePool`` are both specified, ``resourcePool`` must
                belong to ``host``. If ``host`` and ``cluster`` are both specified,
                ``host`` must be a member of ``cluster``. **Warning:** This
                attribute is part of a new feature in development. It may be
                changed at any time and may not have all supported functionality
                implemented.
                When clients pass a value of this class as a parameter, the
                attribute must be an identifier for the resource type:
                ``HostSystem``. When methods return a value of this class as a
                return value, the attribute will be an identifier for the resource
                type: ``HostSystem``.
                This attribute may be None if ``resourcePool`` or ``cluster`` is
                specified. If None, the system will attempt to choose a suitable
                host for the virtual machine; if a host cannot be chosen, the
                operation will fail.
            :type  cluster: :class:`str` or ``None``
            :param cluster: Cluster onto which the virtual machine should be placed. If
                ``cluster`` and ``resourcePool`` are both specified,
                ``resourcePool`` must belong to ``cluster``. If ``cluster`` and
                ``host`` are both specified, ``host`` must be a member of
                ``cluster``. **Warning:** This attribute is part of a new feature
                in development. It may be changed at any time and may not have all
                supported functionality implemented.
                When clients pass a value of this class as a parameter, the
                attribute must be an identifier for the resource type:
                ``ClusterComputeResource``. When methods return a value of this
                class as a return value, the attribute will be an identifier for
                the resource type: ``ClusterComputeResource``.
                If ``resourcePool`` or ``host`` is specified, it is recommended
                that this attribute be None.
            """
            self.folder = folder
            self.resource_pool = resource_pool
            self.host = host
            self.cluster = cluster
            VapiStruct.__init__(self)

    PlacementSpec._set_binding_type(type.StructType(
        'com.vmware.vcenter.vm_template.library_items.check_outs.placement_spec', {
            'folder': type.OptionalType(type.IdType()),
            'resource_pool': type.OptionalType(type.IdType()),
            'host': type.OptionalType(type.IdType()),
            'cluster': type.OptionalType(type.IdType()),
        },
        PlacementSpec,
        False,
        None))


    class CheckInInfo(VapiStruct):
        """
        The ``CheckOuts.CheckInInfo`` class contains information about the result
        of the check in method. This class is currently empty. In the future,
        attributes will be added to summarize the check in result. **Warning:**
        This class is part of a new feature in development. It may be changed at
        any time and may not have all supported functionality implemented.

        .. tip::
            The arguments are used to initialize data attributes with the same
            names.
        """




        def __init__(self,
                    ):
            """
            """
            VapiStruct.__init__(self)

    CheckInInfo._set_binding_type(type.StructType(
        'com.vmware.vcenter.vm_template.library_items.check_outs.check_in_info', {
        },
        CheckInInfo,
        False,
        None))



    def check_out(self,
                  template_library_item,
                  spec=None,
                  ):
        """
        Checks out a library item containing a virtual machine template. This
        method makes a copy of the source virtual machine template contained in
        the library item as a virtual machine. The virtual machine is copied
        with the same storage specification as the source virtual machine
        template. Changes to the checked out virtual machine do not affect the
        virtual machine template contained in the library item. To save these
        changes back into the library item, :func:`CheckOuts.check_in` the
        virtual machine. To discard the changes, delete the virtual machine.
        **Warning:** This method is part of a new feature in development. It
        may be changed at any time and may not have all supported functionality
        implemented.

        :type  template_library_item: :class:`str`
        :param template_library_item: Identifier of the content library item containing the source
            virtual machine template to be checked out.
            The parameter must be an identifier for the resource type:
            ``com.vmware.content.library.Item``.
        :type  spec: :class:`CheckOuts.CheckOutSpec` or ``None``
        :param spec: Specification used to check out the source virtual machine template
            as a virtual machine.
            This parameter is currently required. In the future, if this
            parameter is None, the system will apply suitable defaults.
        :rtype: :class:`str`
        :return: Identifier of the virtual machine that was checked out of the
            library item.
            The return value will be an identifier for the resource type:
            ``VirtualMachine``.
        :raise: :class:`com.vmware.vapi.std.errors_client.AlreadyExists` 
            if a virtual machine with the name specified by
            :attr:`CheckOuts.CheckOutSpec.name` already exists in the folder
            specified by :attr:`CheckOuts.PlacementSpec.folder`.
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidArgument` 
             if ``spec`` contains invalid arguments.
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
            if the library item specified by ``template_library_item`` cannot
            be found.
        :raise: :class:`com.vmware.vapi.std.errors_client.ResourceInaccessible` 
            if there is an error accessing the files of the source virtual
            machine template contained in the library item specified by
            ``template_library_item``.
        :raise: :class:`com.vmware.vapi.std.errors_client.UnableToAllocateResource` 
            if the limit for the number of virtual machines checked out of a
            library item (currently 1) has been exceeded.
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthenticated` 
             if the user that requested the method cannot be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
            if the user that requested the method is not authorized to perform
            the method.
        :raise: :class:`com.vmware.vapi.std.errors_client.Error` 
             if the system reports an error while responding to the request.
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized`
            if you do not have all of the privileges described as follows: 
            
            * Method execution requires ``System.Read``.
            * The resource ``com.vmware.content.library.Item`` referenced by
              the parameter ``template_library_item`` requires ``System.Read``.
            * The resource ``Folder`` referenced by the attribute
              :attr:`CheckOuts.PlacementSpec.folder` requires ``System.Read``.
            * The resource ``ResourcePool`` referenced by the attribute
              :attr:`CheckOuts.PlacementSpec.resource_pool` requires
              ``System.Read``.
            * The resource ``HostSystem`` referenced by the attribute
              :attr:`CheckOuts.PlacementSpec.host` requires ``System.Read``.
            * The resource ``ClusterComputeResource`` referenced by the
              attribute :attr:`CheckOuts.PlacementSpec.cluster` requires
              ``System.Read``.
        """
        return self._invoke('check_out',
                            {
                            'template_library_item': template_library_item,
                            'spec': spec,
                            })

    def check_in(self,
                 template_library_item,
                 vm,
                 ):
        """
        Checks in a virtual machine into the library item. This method updates
        the library item to contain the virtual machine being checked in as a
        template. The original source virtual machine template contained in the
        library item is no longer available. A virtual machine can only be
        checked into the item that it was previously checked out of.
        **Warning:** This method is part of a new feature in development. It
        may be changed at any time and may not have all supported functionality
        implemented.

        :type  template_library_item: :class:`str`
        :param template_library_item: Identifier of the content library item in which the virtual machine
            is checked in.
            The parameter must be an identifier for the resource type:
            ``com.vmware.content.library.Item``.
        :type  vm: :class:`str`
        :param vm:  Identifier of the virtual machine to check into the library item.
            The parameter must be an identifier for the resource type:
            ``VirtualMachine``.
        :rtype: :class:`CheckOuts.CheckInInfo`
        :return: Information about the result of the check in method.
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidArgument` 
             if any of the specified parameters are invalid.
        :raise: :class:`com.vmware.vapi.std.errors_client.InvalidArgument` 
            if the virtual machine identified by ``vm`` was not checked out of
            the item specified by ``template_library_item``.
        :raise: :class:`com.vmware.vapi.std.errors_client.NotAllowedInCurrentState` 
            if the method cannot be performed because of the virtual machine's
            current state. For example, if the virtual machine is not powered
            off.
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             if the item specified by ``template_library_item`` does not exist.
        :raise: :class:`com.vmware.vapi.std.errors_client.NotFound` 
             if the virtual machine specified by ``vm`` does not exist.
        :raise: :class:`com.vmware.vapi.std.errors_client.ResourceInaccessible` 
             if there is an error accessing a file from the virtual machine.
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthenticated` 
             if the user that requested the method cannot be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized` 
            if the user that requested the method is not authorized to perform
            the method.
        :raise: :class:`com.vmware.vapi.std.errors_client.Error` 
             if the system reports an error while responding to the request.
        :raise: :class:`com.vmware.vapi.std.errors_client.Unauthorized`
            if you do not have all of the privileges described as follows: 
            
            * Method execution requires ``System.Read``.
            * The resource ``com.vmware.content.library.Item`` referenced by
              the parameter ``template_library_item`` requires ``System.Read``.
            * The resource ``VirtualMachine`` referenced by the parameter
              ``vm`` requires ``System.Read``.
        """
        return self._invoke('check_in',
                            {
                            'template_library_item': template_library_item,
                            'vm': vm,
                            })
class _CheckOutsStub(ApiInterfaceStub):
    def __init__(self, config):
        # properties for check_out operation
        check_out_input_type = type.StructType('operation-input', {
            'template_library_item': type.IdType(resource_types='com.vmware.content.library.Item'),
            'spec': type.OptionalType(type.ReferenceType(__name__, 'CheckOuts.CheckOutSpec')),
        })
        check_out_error_dict = {
            'com.vmware.vapi.std.errors.already_exists':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'AlreadyExists'),
            'com.vmware.vapi.std.errors.invalid_argument':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidArgument'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),
            'com.vmware.vapi.std.errors.resource_inaccessible':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ResourceInaccessible'),
            'com.vmware.vapi.std.errors.unable_to_allocate_resource':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'UnableToAllocateResource'),
            'com.vmware.vapi.std.errors.unauthenticated':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthenticated'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Error'),

        }
        check_out_input_value_validator_list = [
        ]
        check_out_output_validator_list = [
        ]
        check_out_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/vcenter/vm-template/library-items/{item}/check-outs',
            path_variables={
                'template_library_item': 'item',
            },
            query_parameters={
            }
        )

        # properties for check_in operation
        check_in_input_type = type.StructType('operation-input', {
            'template_library_item': type.IdType(resource_types='com.vmware.content.library.Item'),
            'vm': type.IdType(resource_types='VirtualMachine'),
        })
        check_in_error_dict = {
            'com.vmware.vapi.std.errors.invalid_argument':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'InvalidArgument'),
            'com.vmware.vapi.std.errors.not_allowed_in_current_state':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotAllowedInCurrentState'),
            'com.vmware.vapi.std.errors.not_found':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'NotFound'),
            'com.vmware.vapi.std.errors.resource_inaccessible':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'ResourceInaccessible'),
            'com.vmware.vapi.std.errors.unauthenticated':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthenticated'),
            'com.vmware.vapi.std.errors.unauthorized':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Unauthorized'),
            'com.vmware.vapi.std.errors.error':
                type.ReferenceType('com.vmware.vapi.std.errors_client', 'Error'),

        }
        check_in_input_value_validator_list = [
        ]
        check_in_output_validator_list = [
        ]
        check_in_rest_metadata = OperationRestMetadata(
            http_method='POST',
            url_template='/vcenter/vm-template/library-items/{item}/check-outs/{vm}',
            path_variables={
                'template_library_item': 'item',
                'vm': 'vm',
            },
            query_parameters={
            }
        )

        operations = {
            'check_out': {
                'input_type': check_out_input_type,
                'output_type': type.IdType(resource_types='VirtualMachine'),
                'errors': check_out_error_dict,
                'input_value_validator_list': check_out_input_value_validator_list,
                'output_validator_list': check_out_output_validator_list,
                'task_type': TaskType.NONE,
            },
            'check_in': {
                'input_type': check_in_input_type,
                'output_type': type.ReferenceType(__name__, 'CheckOuts.CheckInInfo'),
                'errors': check_in_error_dict,
                'input_value_validator_list': check_in_input_value_validator_list,
                'output_validator_list': check_in_output_validator_list,
                'task_type': TaskType.NONE,
            },
        }
        rest_metadata = {
            'check_out': check_out_rest_metadata,
            'check_in': check_in_rest_metadata,
        }
        ApiInterfaceStub.__init__(
            self, iface_name='com.vmware.vcenter.vm_template.library_items.check_outs',
            config=config, operations=operations, rest_metadata=rest_metadata,
            is_vapi_rest=True)


class StubFactory(StubFactoryBase):
    _attrs = {
        'CheckOuts': CheckOuts,
    }

